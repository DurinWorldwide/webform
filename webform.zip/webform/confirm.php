<?php

	session_start();
	echo $_SESSION['code'];
	exit(0);
?>